<!--
<head>
   <link rel ="stylesheet" type="text/css"
         href="grid.css"/>
    
    
</head>
<body  style=" background-image: url(back.jpg)"> 
    

<nav class="nav nav-tabs navbar navbar-inverse navbar-fixed-top" style="margin: 0">
  <div class="container" style="padding-top:10px; padding-bottom:10px; ">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="home.html">Lost Phone</a> 
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
	<form class="navbar-form navbar-left" name="search" method ="post" action="search.php">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Enter IMEI Number" style="width:600px">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>
    <ul class="nav navbar-nav navbar-right">
	  <li><a href="#">Notifications</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> Admin</a></li>
	  <li><a href="signin.html"><span class="glyphicon glyphicon-log-out"></span> Signout</a></li>
    </ul>
    </div>
  </div>
</nav>
    -->
    
             
        
        









<?php
//step1...... create connection
$con =mysqli_connect("localhost","root","","lostphone");

//step 2
 echo $imei=$_POST['imei'];
 echo $brand=$_POST['brand'];
 echo $dop=$_POST['dop'];
echo $shopname=$_POST['shopname'];
 echo $dol=$_POST['dol'];
echo $name=$_POST['name'];
echo $address=$_POST['address'];
 echo $phoneno=$_POST['phoneno'];


echo $query = "INSERT INTO lostmobile(imei,brand,dop,shopname,dol,name,address,phonenumber)
    VALUES('$imei','$brand','$dop','$shopname','$dol','$name','$address','$phoneno')";


$result= mysqli_query($con ,$query);
if($result){
	header('location: viewphones.php');
}else{
	header('location: error.php');
}

?>
